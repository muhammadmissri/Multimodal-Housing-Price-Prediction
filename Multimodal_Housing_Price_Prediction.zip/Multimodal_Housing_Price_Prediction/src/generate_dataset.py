"""
generate_dataset.py
--------------------
Generates a synthetic but realistic multimodal housing dataset:
  1. A tabular CSV with structured house features (area, bedrooms, bathrooms,
     stories, age, garage, location_score, condition, etc.)
  2. A matching synthetic "house image" (PNG) for every row, where visual
     attributes (house size/silhouette, number of window rows, roof color,
     façade tone, presence of a garage door, yard greenery) are deliberately
     correlated with the tabular features and the final price.

Why synthetic data?
This task is normally done with a public Kaggle dataset (e.g. "Housing Sales
Dataset" + a folder of real house photos). Since this environment has no
internet access to download Kaggle data or real photographs, we generate a
controlled synthetic dataset instead. Crucially, the images are NOT random
noise -- visual features are programmatically tied to the same underlying
"house quality" latent variable that drives price, the same way real house
photos correlate with real house value. This lets the CNN branch actually
learn something meaningful from pixels, so the multimodal fusion experiment
is genuine rather than cosmetic.

To use a REAL dataset instead: replace this script's output (housing.csv +
images/house_<id>.png) with your own Kaggle CSV + photo folder, keeping the
same column names / id-to-filename convention, and the rest of the notebook
will work unmodified.
"""

import os
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

np.random.seed(42)

N_SAMPLES = 600
IMG_SIZE = 96  # keep small -> fast CNN training on CPU

OUT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(OUT_DIR, "data")
IMG_DIR = os.path.join(DATA_DIR, "images")
os.makedirs(IMG_DIR, exist_ok=True)


def make_house_image(quality, area_norm, bedrooms, garage, condition, size=IMG_SIZE):
    """
    Draws a simple procedural house facade whose visual properties depend on
    `quality` (0-1 latent driving price) and a few tabular attributes, so the
    CNN has real signal to learn from.

    - Higher quality -> brighter/warmer facade color, neater roof color,
      larger windows, landscaped (greener) yard strip.
    - Larger area_norm -> wider house silhouette.
    - More bedrooms -> more window columns.
    - garage=1 -> a garage door rectangle is drawn.
    - Lower condition -> added "noise speckle" to simulate wear/disrepair.
    """
    img = Image.new("RGB", (size, size), (135 + int(20 * quality), 206, 250))  # sky
    draw = ImageDraw.Draw(img)

    # ground / yard - greener with higher quality (landscaping)
    yard_green = (60 + int(80 * quality), 130 + int(60 * quality), 60)
    draw.rectangle([0, size * 0.72, size, size], fill=yard_green)

    # house body
    house_w = size * (0.45 + 0.35 * area_norm)
    house_h = size * 0.32
    x0 = (size - house_w) / 2
    y0 = size * 0.40
    x1 = x0 + house_w
    y1 = y0 + house_h

    facade_color = (
        180 + int(50 * quality),
        140 + int(70 * quality),
        110 + int(60 * quality),
    )
    draw.rectangle([x0, y0, x1, y1], fill=facade_color, outline=(60, 60, 60))

    # roof - triangle, color reflects quality (darker/richer = better maintained)
    roof_color = (90 - int(40 * quality), 40, 40 + int(20 * quality))
    draw.polygon(
        [(x0 - 6, y0), (x1 + 6, y0), ((x0 + x1) / 2, y0 - size * 0.18)],
        fill=roof_color,
    )

    # windows - count depends on bedrooms, brighter glass with higher quality
    n_windows = max(2, min(6, bedrooms))
    win_color = (200 + int(40 * quality), 230 + int(20 * quality), 250)
    win_w = house_w / (n_windows * 1.8)
    win_h = house_h * 0.32
    spacing = house_w / n_windows
    for i in range(n_windows):
        wx = x0 + spacing * i + spacing / 2 - win_w / 2
        wy = y0 + house_h * 0.18
        draw.rectangle([wx, wy, wx + win_w, wy + win_h], fill=win_color, outline=(40, 40, 40))

    # door
    door_w, door_h = house_w * 0.10, house_h * 0.55
    dx = (x0 + x1) / 2 - door_w / 2
    dy = y1 - door_h
    draw.rectangle([dx, dy, dx + door_w, dy + door_h], fill=(80, 50, 30))

    # garage door if present
    if garage == 1:
        gw, gh = house_w * 0.22, house_h * 0.45
        gx = x1 - gw - 4
        gy = y1 - gh
        draw.rectangle([gx, gy, gx + gw, gy + gh], fill=(170, 170, 175), outline=(50, 50, 50))

    # condition noise: lower condition -> speckled "wear" dots on the facade
    if condition < 6:
        n_specks = int((6 - condition) * 25)
        xs = np.random.randint(int(x0), int(x1), n_specks)
        ys = np.random.randint(int(y0), int(y1), n_specks)
        for sx, sy in zip(xs, ys):
            draw.point((sx, sy), fill=(70, 70, 70))

    return img


def generate():
    rows = []
    for i in range(N_SAMPLES):
        area = np.random.randint(500, 5500)  # sqft
        bedrooms = np.random.randint(1, 6)
        bathrooms = np.random.randint(1, 4)
        stories = np.random.randint(1, 4)
        age = np.random.randint(0, 60)  # years
        garage = np.random.choice([0, 1], p=[0.35, 0.65])
        location_score = np.round(np.random.uniform(1, 10), 1)  # neighborhood desirability
        condition = np.random.randint(1, 10)  # 1=poor, 9=excellent

        area_norm = (area - 500) / (5500 - 500)
        # latent "quality" drives both image appearance and price
        quality = np.clip(
            0.35 * area_norm
            + 0.20 * (condition / 9)
            + 0.20 * (location_score / 10)
            + 0.15 * (1 - age / 60)
            + 0.10 * garage
            + np.random.normal(0, 0.03),
            0,
            1,
        )

        # price formula: structured drivers + quality term + noise
        base_price = (
            area * 80
            + bedrooms * 4000
            + bathrooms * 6000
            + stories * 3000
            - age * 500
            + garage * 8000
            + location_score * 9000
            + condition * 3500
        )
        price = base_price * (0.85 + 0.3 * quality) + np.random.normal(0, 9000)
        price = max(20000, price)

        img = make_house_image(quality, area_norm, bedrooms, garage, condition)
        fname = f"house_{i:04d}.png"
        img.save(os.path.join(IMG_DIR, fname))

        rows.append(
            {
                "house_id": i,
                "area_sqft": area,
                "bedrooms": bedrooms,
                "bathrooms": bathrooms,
                "stories": stories,
                "age_years": age,
                "garage": garage,
                "location_score": location_score,
                "condition": condition,
                "image_file": fname,
                "price": round(price, 2),
            }
        )

    df = pd.DataFrame(rows)
    csv_path = os.path.join(DATA_DIR, "housing.csv")
    df.to_csv(csv_path, index=False)
    print(f"Saved {len(df)} rows to {csv_path}")
    print(f"Saved {len(df)} images to {IMG_DIR}")
    print(df.head())
    return df


if __name__ == "__main__":
    generate()
